
package Scanner;
import java.util.Scanner;

/**
 *
 * @MuhTegar
 */
public class VolumeKerucut {
   public static void main(String[]args){
       Scanner scan = new Scanner(System.in);
       double volume, radius, tinggi;
       
       System.out.print("masukkan nilai radius=");
       radius = Double.valueOf(scan.nextLine());
       
       System.out.print("masukkan nilai tinggi=");
       tinggi = Double.valueOf(scan.nextLine());
       
       volume = 0.1/0.3*3.14*radius*radius*tinggi;
       System.out.println("Hasil volume kerucut="+volume);
       
       //radius = jari-jari
       
       
   }
           
}
