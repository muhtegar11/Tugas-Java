
package Scanner;
import java.util.Scanner;

/**
 *
 * @MuhTegar
 */
public class LuasTabung {
    public static void main(String[]args){
        Scanner scan = new Scanner(System.in);
        double luas, radius, tinggi;
        
        System.out.print("masukkan nilai radius =");
        radius = Double.valueOf(scan.nextLine());
        
        System.out.print("masukkan nilai tinggi =");
        tinggi = Double.valueOf(scan.nextLine());
        
        luas = (2*3.14*radius*tinggi)+(2*3.14*radius*radius);
        System.out.println("Hasil luas tabung ="+luas);
        
        //radius = jari-jari
    }
}
