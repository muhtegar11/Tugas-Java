
package Scanner;
import java.util.Scanner;

/**
 *
 * @MuhTegar
 */
public class LuasBola {
    public static void main(String[]args){
        Scanner scan = new Scanner(System.in);
        double luas, radius;
        
        System.out.print("masukkan nilai radius = ");
        radius = Double.valueOf(scan.nextLine());
        
        luas = 4*3.14*radius*radius;
        System.out.println("Hasil luas bola ="+luas);
    
        //radius = jari-jari
}
    
}
