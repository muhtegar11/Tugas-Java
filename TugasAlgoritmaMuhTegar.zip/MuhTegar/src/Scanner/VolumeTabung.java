
package Scanner;
import java.util.Scanner;
/**
 *
 * @MuhTegar
 */
public class VolumeTabung {
 public static void main(String[]args){
     Scanner scan = new Scanner(System.in);
     double volume, radius, tinggi;
     
     System.out.print("masukkan nilai radius=");
     radius = Double.valueOf(scan.nextLine());
     
     System.out.print("masukkan nilai tinggi=");
     tinggi = Double.valueOf(scan.nextLine());
     
     volume = 3.14*radius*radius*tinggi;
     System.out.println("Hasil volume tabung="+volume);
     
     //radius = jari-jari
    
}    
}
