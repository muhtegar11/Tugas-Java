
package Scanner;
import java.util.Scanner;

/**
 *
 * @MuhTegar
 */
public class LuasKerucut {
    public static void main(String[]args){
        Scanner scan = new Scanner(System.in);
        double luas, jari_jari_alas, garis_pelukis;
        
        System.out.print("masukkan nilai jari-jari alas =");
        jari_jari_alas = Double.valueOf(scan.nextLine());
        
        System.out.print("masukkan nilai garis pelukis = ");
        garis_pelukis = Double.valueOf(scan.nextLine());
        
        luas = 3.14*jari_jari_alas*jari_jari_alas+3.14*jari_jari_alas*garis_pelukis;
        System.out.println("Hasil luas kerucut ="+luas);
        
                
        
    }
    
}
