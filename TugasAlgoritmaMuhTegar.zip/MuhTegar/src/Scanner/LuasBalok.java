
package Scanner;
import java.util.Scanner;
/**
 *
 * @MuhTegar
 */
public class LuasBalok {
 public static void main(String[]args){
     Scanner scan = new Scanner(System.in);
     int luas, panjang, lebar, tinggi;
     
     System.out.print("masukkan nilai panjang =");
     panjang = Integer.parseInt(scan.nextLine());
     
     System.out.print("masukkan nilai lebar = ");
     lebar = Integer.parseInt(scan.nextLine());
     
     System.out.print("masukkan nilai tinggi = ");
     tinggi = Integer.parseInt(scan.nextLine());
     
     luas = 2*(panjang*lebar+panjang*tinggi+lebar*tinggi);
     System.out.println("Hasil luas balok = "+luas);
 
 }   
}
