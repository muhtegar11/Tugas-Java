
package Scanner;
import java.util.Scanner;
/**
 *
 * @MuhTegar
 */
public class VolumeBalok {
  public static void main(String[] args){
      Scanner scan = new Scanner(System.in);
      int volume, panjang, lebar, tinggi;
     
      System.out.print("inputkan nilai panjang=");
      panjang = Integer.parseInt(scan.nextLine());
      
      System.out.print("inputkan nilai lebar=");
      lebar = Integer.parseInt(scan.nextLine());
      
      System.out.print("inputkan nilai tinggi =");
      tinggi = Integer.parseInt(scan.nextLine());
      
      
      volume = panjang*lebar*tinggi;
      System.out.println("Hasil volume balok="+volume);
  }
}
